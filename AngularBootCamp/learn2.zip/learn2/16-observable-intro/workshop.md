# Workshop for this step

Subscribe to the valuechanges of the form you created for the previous step, and log it to the console;
