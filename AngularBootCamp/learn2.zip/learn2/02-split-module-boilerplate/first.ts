import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1>My First TypeScript Angular 2 App</h1>'
})
export class FirstComponent { }
