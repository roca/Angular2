import {Component} from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './manager.component.html'
})
export class ManagerComponent {
}
