export var fbName = 'https://a2-fb-demo.firebaseio.com/';
