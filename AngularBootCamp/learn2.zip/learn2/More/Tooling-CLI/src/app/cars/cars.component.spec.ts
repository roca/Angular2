/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CarsComponent } from './cars.component';

describe('Component: Cars', () => {
  it('should create an instance', () => {
    let component = new CarsComponent();
    expect(component).toBeTruthy();
  });
});
