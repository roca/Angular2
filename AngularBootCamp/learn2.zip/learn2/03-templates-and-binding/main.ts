import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { SomeModule1 } from './app';

platformBrowserDynamic().bootstrapModule(SomeModule1);
