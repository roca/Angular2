# Workshop for this step

Your application probably contains several components which mix
backend interface functionality with display functionality. Split at
least two of those in to pairs of components: Smart and Presentation.
