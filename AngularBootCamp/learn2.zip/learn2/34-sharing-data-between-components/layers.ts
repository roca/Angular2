import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: 'app.html'
})
export class LayerComponent { }
