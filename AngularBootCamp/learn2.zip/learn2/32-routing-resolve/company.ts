export interface ICompany {
  name: string;
  phone: string;
  address: string;
}
