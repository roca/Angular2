# Workshop for this step

Add route driven data loading to your project. You already have a list
of things on the screen - make it so that clicking on one will load
details about that one in another screen/route.

To avoid spending hours on the data, just make up a detailed data JSON
file (simulated REST endpoint) for a handful of the entries on your
list.
