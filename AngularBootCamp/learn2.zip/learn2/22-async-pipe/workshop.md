# Workshop for this step

Now that the data is being obtained asynchronously, there is room to
improve. Instead of managing the subscription manually, take advantage
of the async pipe to unpack the data in the template.
