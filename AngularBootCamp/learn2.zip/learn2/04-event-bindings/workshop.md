# Workshop for this step

The instructor may have changes to the workshops, as our curriculum is
under continuous improvement and is adjusted for the needs of each
class.

1. Catch two more events. You can see a list of available events
   here: https://developer.mozilla.org/en-US/docs/Web/Events
