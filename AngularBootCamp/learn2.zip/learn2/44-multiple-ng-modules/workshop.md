# Workshop for this step

1. Consider the components you have created; choose one that you can
   imagine reusing widely.
2. Put it in a shared module.
3. Change the code which uses this component, to use that shared module.

