import { Component } from '@angular/core';

@Component({
  selector: 'folder-list',
  // The following app-relative URL! Not needed with better tooling;
  // for example with CLI we just learned, use './email.html'
  templateUrl: 'email/folder-list.html'
})
export class FolderListComponent { }
