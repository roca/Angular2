import { Component } from '@angular/core';

@Component({
  selector: 'message-body',
  // The following app-relative URL! Not needed with better tooling;
  // for example with CLI we just learned, use './email.html'
  templateUrl: 'email/message-body.html'
})
export class MessageBodyComponent { }
