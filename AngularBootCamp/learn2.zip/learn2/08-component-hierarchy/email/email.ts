import { Component } from '@angular/core';

@Component({
  selector: 'app-email',
  // The following app-relative URL! Not needed with better tooling;
  // for example with CLI we just learned, use './email.html'
  templateUrl: 'email/email.html'
})
export class EmailComponent { }
