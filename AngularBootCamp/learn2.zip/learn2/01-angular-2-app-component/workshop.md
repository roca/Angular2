# Workshop for this step

The instructor may have changes to the workshops, as our curriculum is
under continuous improvement and is adjusted for the needs of each
class.

1. Make sure you can view the step in your browser.
2. Make a trivial adjustment to the displayed text in main.ts.
3. Verify changes appear in your browser.
