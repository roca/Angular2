# Angular 2 is Very Different From AngularJS 1.x

(let's talk)

