to install & Run:

npm install
npm install nodemon -g
cd server
nodemon server.js