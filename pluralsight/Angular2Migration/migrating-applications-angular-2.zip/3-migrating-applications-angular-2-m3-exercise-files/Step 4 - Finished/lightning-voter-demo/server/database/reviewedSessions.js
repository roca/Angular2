var reviewedSessions = [
  {userId: 1, sessions: [
    
  ]},
  {userId: 2, sessions: [
    {id: 1}
  ]},
]

module.exports = reviewedSessions;