/// <reference path="main/ambient/angular-mocks/index.d.ts" />
/// <reference path="main/ambient/angular-route/index.d.ts" />
/// <reference path="main/ambient/angular/index.d.ts" />
/// <reference path="main/ambient/jasmine/index.d.ts" />
/// <reference path="main/ambient/jquery/index.d.ts" />
