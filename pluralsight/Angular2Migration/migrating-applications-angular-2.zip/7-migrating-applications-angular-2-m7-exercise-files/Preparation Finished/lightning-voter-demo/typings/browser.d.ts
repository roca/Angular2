/// <reference path="browser/ambient/angular-mocks/index.d.ts" />
/// <reference path="browser/ambient/angular-route/index.d.ts" />
/// <reference path="browser/ambient/angular/index.d.ts" />
/// <reference path="browser/ambient/jasmine/index.d.ts" />
/// <reference path="browser/ambient/jquery/index.d.ts" />
